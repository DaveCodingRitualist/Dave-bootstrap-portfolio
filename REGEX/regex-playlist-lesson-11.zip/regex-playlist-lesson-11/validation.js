var myregex = /[a-z]+[0-9]+/ig;
